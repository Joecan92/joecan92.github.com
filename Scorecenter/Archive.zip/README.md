Joe Canuel
README for A5
1.I believe all parts of the assignment have been correctly implemented.
2.I collaborated with Ronald Hong.
3.Approximate hours spent: 10-12 hours (Most was struggling understanding Mongo stuff.
I didn't realize Heroku creates the database so I was testing the database stuff for a 
while. I also wanted to mention I have many commits that are simply playing with 
the database creation.)