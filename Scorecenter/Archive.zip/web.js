// Express initialization
var express = require('express');
var app = express(express.logger());
app.use(express.bodyParser());
app.set('title', 'nodeapp');

// Mongo initialization
var dbURL = process.env.MONGOLAB_URI;
var collections = ['highscores'];            
var db = require('mongojs').connect(dbURL, collections);

app.all('*', function(req, res, next) {
  res.header('Access-Control-Allow-Origin', '*');
  res.header('Access-Control-Allow-Methods', 'PUT, GET, POST, DELETE, OPTIONS');
  res.header('Access-Control-Allow-Headers', 'Content-Type');
  next();
});

app.get('/', function (request, response) {
	db.highscores.find(function(err, all_scores){
		if(err) response.send('<p> ERROR: ' + err + '</p>');
		else{
			var formatted_scores = "";
			for(i = 0; i < all_scores.length; i++){ //Format scores.
				if(all_scores[i]) formatted_scores += 
					'Game: ' + all_scores[i].game_title + '&nbsp' +
					' Username: ' + all_scores[i].username + '&nbsp' + 
					'  Score: ' + all_scores[i].score + '&nbsp' + 
					' Created at: ' + all_scores[i].created_at +  '</br>';
			}
			response.set('Content-Type', 'text/html');
			response.send('<p>' + formatted_scores +  '</p>'); //Send formatted scores. 
		}
	});
});

app.get('/highscores.json', function(request, response) {
	game_title = request.query.game_title;
	response.set('Content-Type', 'text/json');
	if(!game_title) response.send("No game title specified. Please specify a game title.");
	else{
		db.highscores.find({'game_title':game_title}, function(err, all_scores){
			if(err) response.send('<p> ERROR: ' + err + '</p>');
			else{
				if(!all_scores[0]){
			 		response.send("No scores for " + game_title) 	
			 	}
			 	else{ //Now have all the scores. Need to get the 10 high scores.
			 		  //Inefficent bubble sort. 
			 		 length = all_scores.length;
			 		 ten_or_all = Math.min(10, length);
			 		 var temp;
			 		 var high_scores = new Array();
			 		 for(i = 0; i < ten_or_all; i++){
			 		 	temp = undefined;
			 		 	for(j = 0; j < length; j++){
				 			if(temp == undefined && all_scores[j]!= undefined) temp = j;
				 			if(all_scores[j] != undefined)
				 				if(all_scores[temp].score <  all_scores[j].score) temp = j;
				 		} 
				 		high_scores[i] = all_scores[temp];
				 		all_scores[temp] = undefined;
			 		 }
					response.send(high_scores);
					//Send the high scores as a JSON string.
				}
			}
		});
	}

});

//This app.get is called by '/usersearch' with a required parameter username.
app.get('/search', function(request, response){
	username = request.query.username;
	response.set('Content-Type', 'text/json');
	if(!username) response.send("No username specified. Please specify a username.");
	else
		db.highscores.find({'username':username}, function(err, user_scores){
			if(err) response.send('<p> ERROR: ' + err + '</p>');
			else response.send(user_scores);
		});
});

app.get('/usersearch', function(request, response) {
	response.set('Content-Type', 'text/html');
	response.send(
		'<form name="search" action="search" method="get">' +
		'Username: <input type="text" id="input" name="username">' + 
		'<input type="submit" id="submit" value="Submit"> </form>');
});

app.post('/submit.json', function(request, response){
	game_title = request.body.game_title;
	username = request.body.username;
	score = request.body.score;
	created_at = Date();
	db.highscores.save({'game_title': game_title, 'username':username, 'score':score, 'created_at':created_at}, function(err, savedScore){
		if(err) console.log('ERROR: ' + err);
		else console.log('Saved');
	}); 

});

app.listen(process.env.PORT || 3000);
